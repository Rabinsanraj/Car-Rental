import './App.css'
import Navebar from './Component/Navebar'
import Footer from './Component/Footer'

function App() {
  return (
    <>
      <Navebar/>
      <Footer/>
    </>
  )
}

export default App
